/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import java.util.Date;

/**
 *
 * @author yiyangyang
 */
public class Flight {

	private String id;
	private Airplane airplane;
        private String date;
	private String destination;
	private String departure;
	private Airliner airliner;
	private Seat[][] seats;
	private int sumOfPrice;
        private String preferedDay;

        public String getPreferedDay() {
            return preferedDay;
        }

        public void setPreferedDay(String preferedDay) {
            this.preferedDay = preferedDay;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }
        
        
	public Airliner getAirliner() {
		return airliner;
	}

	public void setAirliner(Airliner airliner) {
		this.airliner = airliner;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public Airplane getAirplane() {
		return airplane;
	}

	public void setAirplane(Airplane airplane) {
		this.airplane = airplane;
	}

	public int getSumOfPrice() {
		sumOfPrice = 0;
		for (int row = 0; row < 25; row++) {
			for (int col = 0; col < 6; col++) {
				Seat seat = this.seats[row][col];
				if (seat != null && seat.getCustomer() != null) {
					sumOfPrice += seat.getPrice();
				}
			}
		}
		return sumOfPrice;
	}

	public Seat[][] getSeats() {
		return seats;
	}

	public void setSeats(Seat[][] seats) {
		this.seats = seats;
	}


//	public Seat addSeat(Customer cus) {
//		for (int row = 0; row < 25; row++) {
//			for (int col = 0; col < 6; col++) {
//				Seat st = this.seats[row][col];
//				if (st.getCustomer() == null) {
//					st.setCustomer(cus);
//					return st;
//				}
//			}
//		}
//		return new Seat();
//	}
//        
       public Seat addSeat(Customer cus) {
		Seat st = new Seat();
                st.setCustomer(cus);
		return st;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
        @Override
    public String toString(){
        return id;  //!!!!!!!
    }

}
